"""An actual LangGraph agent workflow, deliberately unaware of recovery backends.
This file is the unintegrated framework application used for the integration diff.
"""
from pathlib import Path
import sqlite3,time,json
from typing import TypedDict
from langgraph.graph import StateGraph,START,END
from langgraph.checkpoint.sqlite import SqliteSaver
import runtime as rt

class State(TypedDict,total=False):
 seed:int
 attempt:int
 messages:list
 ok:bool
 narrative:str
 native_receipt:dict

class GraphRunner:
 def __init__(self,root):
  self.root=Path(root);self.connection=sqlite3.connect(self.root/'graph.sqlite',check_same_thread=False)
  self.saver=SqliteSaver(self.connection);self.config={'configurable':{'thread_id':'research-history'}}
  builder=StateGraph(State)
  for name in ['prepare','generate','execute','report','publish','dispatch']:
   builder.add_node(name,self.node(name))
  builder.add_edge(START,'prepare');builder.add_edge('prepare','generate');builder.add_edge('generate','execute')
  builder.add_conditional_edges('execute',lambda s:'report' if s['ok'] else ('generate' if s['attempt']<3 else END),{'report':'report','generate':'generate',END:END})
  builder.add_edge('report','publish');builder.add_edge('publish','dispatch');builder.add_edge('dispatch',END)
  self.graph=builder.compile(checkpointer=self.saver,interrupt_before=['dispatch'])

 def node(self,name):
  def run(state):
   rt.log(self.root,'graph_node_start',node=name)
   if name=='prepare':value={'messages':rt.code_messages(self.root),'attempt':0,'ok':False}
   elif name=='generate':
    code=rt.generate(self.root,state['messages'],state['seed']);value={'messages':state['messages']+[{'role':'assistant','content':code}],'attempt':state['attempt']+1}
   elif name=='execute':
    ok,feedback=rt.execute(self.root);value={'ok':ok}
    if not ok:value['messages']=state['messages']+[{'role':'user','content':'Repair this script using the actual execution feedback. Do not guess target values. '+feedback}]
   elif name=='report':value={'narrative':rt.report(self.root,state['seed'])}
   elif name=='publish':rt.publish(self.root,state['narrative']);value={}
   else:rt.consume(self.root);value={}
   rt.log(self.root,'graph_node_end',node=name);return value
  return run

 def start(self,seed):return self.graph.invoke({'seed':seed,'attempt':0,'messages':[],'ok':False},self.config)
 def pre_analysis_checkpoint(self):
  snap=next(s for s in self.graph.get_state_history(self.config) if s.next==('prepare',))
  return {'resume_stage':'analyze','langgraph_config':snap.config,'next_nodes':list(snap.next)}
 def resume(self,checkpoint):
  selected=self.graph.get_state(checkpoint['langgraph_config'])
  assert selected.next==('prepare',),'not an authentic pre-analysis checkpoint'
  rt.log(self.root,'native_checkpoint_replay',checkpoint_id=checkpoint['langgraph_config']['configurable']['checkpoint_id'],next_nodes=list(selected.next))
  return self.graph.invoke(None,checkpoint['langgraph_config'])
 def dispatch(self):
  snap=self.graph.get_state(self.config)
  if snap.next==('dispatch',):return self.graph.invoke(None,snap.config)
  return snap.values
 def history(self):
  return [{'config':s.config,'next':list(s.next),'created_at':s.created_at,'metadata':s.metadata,'keys':sorted(s.values.keys())} for s in self.graph.get_state_history(self.config)]
 def close(self):
  rt.put(self.root/'graph_history.json',self.history());self.connection.close()
