"""Numerical contract oracle, computed from public input CSVs, never model outputs.
Not an expert evaluation or an official benchmark scientific-ground-truth label.
"""
from pathlib import Path
import json,math
import numpy as np
import pandas as pd

def expected(task,evidence):
 e=Path(evidence);d=pd.read_csv(e/'data.csv');more=json.loads((e/'requirements.json').read_text())['version']>=2
 if task=='smoke':
  x=d.x.dropna().to_numpy();r={'mean':float(np.mean(x))}
  if more:r['median']=float(np.median(x))
 elif task=='co2':
  d=d.dropna(subset=['co2','decimal_year']);x=d.decimal_year.to_numpy();y=d.co2.to_numpy();slope=np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean());r={'mean_co2':float(y.mean()),'slope_per_year':float(slope)}
  if more:
   means=d.groupby('month').co2.mean();r['seasonal_range']=float(means.max()-means.min())
 elif task=='sunspots':
  d=d.sort_values('YEAR').dropna(subset=['YEAR','SUNACTIVITY']);x=d.YEAR.to_numpy();y=d.SUNACTIVITY.to_numpy();r={'mean_activity':float(y.mean()),'slope_per_year':float(np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean()))}
  if more:r['lag1_correlation']=float(np.corrcoef(y[:-1],y[1:])[0,1])
 elif task=='nile':
  d=d.dropna(subset=['volume']);r={'mean_volume':float(d.volume.mean()),'median_volume':float(d.volume.median())}
  if more:r['post1900_minus_pre1900']=float(d.loc[d.year>=1900,'volume'].mean()-d.loc[d.year<1900,'volume'].mean())
 elif task=='grunfeld':
  d=d.dropna(subset=['invest','value','capital','firm']);X=np.column_stack([np.ones(len(d)),d.value,d.capital]);b=np.linalg.lstsq(X,d.invest.to_numpy(),rcond=None)[0];r=dict(zip(['intercept','value_coef','capital_coef'],map(float,b)))
  if more:
   x=d[['invest','value','capital']]-d.groupby('firm')[['invest','value','capital']].transform('mean');r['within_value_coef']=float(np.linalg.lstsq(x[['value','capital']].to_numpy(),x.invest.to_numpy(),rcond=None)[0][0])
 elif task=='copper':
  cols=['WORLDCONSUMPTION','COPPERPRICE','INCOMEINDEX'];d=d[cols].dropna();d=d.loc[(d>0).all(axis=1)];y=np.log(d.WORLDCONSUMPTION.to_numpy());X=np.column_stack([np.ones(len(d)),np.log(d.COPPERPRICE),np.log(d.INCOMEINDEX)]);b=np.linalg.lstsq(X,y,rcond=None)[0];r=dict(zip(['intercept','price_coef','income_coef'],map(float,b)))
  if more:r['r_squared']=float(1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2))
 elif task=='macrodata':
  d=d.sort_values(['year','quarter']);g=100*np.log(d.realgdp).diff();r={'mean_growth':float(g.mean()),'mean_inflation':float(d.infl.mean())}
  if more:
   pairs=pd.DataFrame({'g':g,'u':d.unemp}).dropna();r['growth_unemployment_correlation']=float(np.corrcoef(pairs.g,pairs.u)[0,1])
 else:raise ValueError('unknown task')
 assert all(math.isfinite(v) for v in r.values());return r

def check(task,evidence,analysis):
 target=expected(task,evidence);values=analysis.get('estimates',{});errors=[]
 if set(values)!=set(target):errors.append('estimate keys must exactly match required keys; missing='+str(sorted(set(target)-set(values)))+'; unexpected='+str(sorted(set(values)-set(target))))
 for k,v in target.items():
  x=values.get(k)
  if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x):errors.append(k+': missing or non-finite')
  elif not math.isclose(x,v,rel_tol=1e-6,abs_tol=1e-6):errors.append(k+': numerical contract mismatch; recompute from public data')
 return {'pass':not errors,'expected':target,'errors':errors,'reference_type':'public-data analytical recomputation, not scientific ground truth'}
