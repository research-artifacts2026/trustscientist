"""Strong native LangGraph checkpoint baseline with complete application cleanup.
No imports of either replay engine. One active decision, matching this workload.
The caller supplies the same recovery information as the other backends.
"""
from pathlib import Path
import hashlib,inspect,json,os,uuid

class NativeCheckpointRecovery:
 def __init__(self,root,policies,runner):self.root=Path(root);self.policies=policies;self.runner=runner
 def state(self):return self.runner.graph.get_state(self.runner.config).values.get('native_receipt')
 def path(self,name):
  p=(self.root/name).resolve()
  if not p.is_relative_to(self.root.resolve()) or p==self.root.resolve():raise ValueError('outside workspace')
  return p
 def sha(self,name):
  p=self.path(name);return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 def policy_hash(self,name):return hashlib.sha256(Path(inspect.getfile(self.policies[name])).read_bytes()).hexdigest()
 def record(self,policy,bindings,context,old_action,outputs=(),checkpoint_before=None):
  deps=sorted(set(bindings));versions={n:self.sha(n) for n in deps}
  if any(v is None for v in versions.values()):raise ValueError('missing initial dependency')
  for p in outputs:self.path(p)
  if self.policies[policy](self.root,deps,context)!=old_action:raise ValueError('action not reproducible')
  r={'policy':policy,'policy_hash':self.policy_hash(policy),'deps':deps,'versions':versions,'context':context,'action':old_action,'outputs':list(outputs),'checkpoint':checkpoint_before}
  self.runner.graph.update_state(self.runner.config,{'native_receipt':r})
 def revalidate(self):
  r=self.state();result={'rollback_index':None,'replayed':[],'blocked':False}
  if not r:return result
  current={p:self.sha(p) for p in r['deps']}
  if self.policy_hash(r['policy'])!=r['policy_hash']:return dict(result,blocked=True,error='policy changed')
  if current==r['versions']:return result
  try:action=self.policies[r['policy']](self.root,r['deps'],r['context'])
  except Exception as exc:return dict(result,blocked=True,error=repr(exc))
  result['replayed']=[{'index':0,'old':r['action'],'new':action}]
  if action==r['action']:
   r['versions']=current;self.runner.graph.update_state(self.runner.config,{'native_receipt':r});return result
  outputs=sorted(set(r['outputs']))
  for a in outputs:
   if any(a!=b and Path(a) in Path(b).parents for b in outputs):raise ValueError('overlap')
   if any(Path(a)==Path(p) or Path(a) in Path(p).parents for p in r['deps']):raise ValueError('output contains dependency')
  destination=self.root/'.native_quarantine'/uuid.uuid4().hex
  for name in outputs:
   src=self.path(name);dst=destination/name;dst.parent.mkdir(parents=True,exist_ok=True)
   if src.exists():os.rename(src,dst)
  (self.root/'checkpoint.json').write_text(json.dumps(r['checkpoint']))
  self.runner.graph.update_state(self.runner.config,{'native_receipt':None})
  return dict(result,rollback_index=0)
