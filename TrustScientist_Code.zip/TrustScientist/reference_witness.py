"""Hand-constructed numerical witnesses, never formal-cohort model outputs."""
from pathlib import Path
import json,tempfile,math
import numpy as np
import pandas as pd
from numeric_reference import expected,check

cases={
 'co2':({'decimal_year':[0,1,2,3],'co2':[1,3,5,7],'month':[1,2,1,2]}, {'mean_co2':4,'slope_per_year':2,'seasonal_range':2}),
 'sunspots':({'YEAR':[0,1,2,3],'SUNACTIVITY':[1,3,5,7]}, {'mean_activity':4,'slope_per_year':2,'lag1_correlation':1}),
 'nile':({'year':[1898,1899,1900,1901],'volume':[1,3,5,7]}, {'mean_volume':4,'median_volume':4,'post1900_minus_pre1900':4}),
 'grunfeld':({'firm':['a','a','a','b','b','b'],'value':[1,2,3,2,3,4],'capital':[2,1,4,3,5,2],'invest':[0,5,4,3,3,11]}, {'intercept':0,'value_coef':0,'capital_coef':0}),
 'copper':({'COPPERPRICE':np.exp([0,1,0,1]),'INCOMEINDEX':np.exp([0,0,1,1]),'WORLDCONSUMPTION':np.exp([1,3,4,6])}, {'intercept':1,'price_coef':2,'income_coef':3,'r_squared':1}),
 'macrodata':({'year':[2000]*4,'quarter':[1,2,3,4],'realgdp':np.exp([0,.01,.03,.06]),'infl':[2,4,6,8],'unemp':[0,1,2,3]}, {'mean_growth':2,'mean_inflation':5,'growth_unemployment_correlation':1}),
}
# Two independent regressors, exact y = 3 + 2*value - capital, with firm levels.
cases['grunfeld'][0]['invest']=[3+2*x-z for x,z in zip(cases['grunfeld'][0]['value'],cases['grunfeld'][0]['capital'])]
cases['grunfeld']=(cases['grunfeld'][0],{'intercept':3,'value_coef':2,'capital_coef':-1,'within_value_coef':2})
results=[]
for task,(data,truth) in cases.items():
 with tempfile.TemporaryDirectory() as tmp:
  e=Path(tmp);pd.DataFrame(data).to_csv(e/'data.csv',index=False)
  (e/'requirements.json').write_text(json.dumps({'version':2}))
  actual=expected(task,e)
  assert set(actual)==set(truth)
  assert all(math.isclose(actual[k],v,rel_tol=1e-9,abs_tol=1e-9) for k,v in truth.items()),(task,actual,truth)
  assert check(task,e,{'estimates':truth})['pass']
  assert not check(task,e,{'estimates':dict(truth,unexpected=1)})['pass']
  wrong=dict(truth);wrong[next(iter(wrong))]+=.25
  assert not check(task,e,{'estimates':wrong})['pass']
  for invalid in [True,float('nan'),None]:
   bad=dict(truth);bad[next(iter(bad))]=invalid
   assert not check(task,e,{'estimates':bad})['pass']
  results.append({'task':task,'expected_hand_constructed':truth,'observed':actual,'valid_pass_and_defect_rejection':True})
out={'status':'PASS','scope':'Six synthetic arithmetic witnesses; not formal task performance','cases':results}
(Path(__file__).parent/'REFERENCE_WITNESS.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
