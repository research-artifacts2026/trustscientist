# TrustScientist current code

This directory contains one current recovery interface, its TrustScientist
engine, the generic comparator, and the frozen LangGraph EXT1 integration.
The comparator backends are experimental controls, not alternative releases.

## Offline check (no API, model or paid service)

```text
python verify_recorded_results.py
```

This recomputes completion, attempted/planned denominators and omission
counts from saved records, and checks source hashes. It does not independently
recompute scientific estimates or token totals from full request caches.

## Files

- `frozen/trust_engine.py`: the single current TrustScientist recovery engine.
- `frozen/workflow_interface.py`: backend-neutral ownership interface.
- `frozen/generic_replay.py`: generic comparison backend.
- `framework_workflow.py`, `integration.py`, `native_backend.py`: LangGraph workflow, glue and native comparison.
- `runtime.py`, `numeric_reference.py`, `prepare_tasks.py`: execution and checks.
- `tasks/`: frozen public task inputs.
- `runs_*records.jsonl`, `SUMMARY.json`: saved EXT1 records, including failures and unexecuted slots.
- `EXPERIMENT_PLAN.md`, `*_FREEZE.json`: original protocol and freeze records.

## Fresh inference

Fresh runs require Linux, the pinned dependencies, a Qwen3-8B compatible
local service and an isolated analysis worker. The frozen runtime contains
the original author-environment worker path and local endpoint; configure
an equivalent environment separately. Do not overwrite frozen records.
No new inference or experiments were run to prepare this release.
Full requests, checkpoints, workspaces and previous study evidence accompany
the paper in S2-S4; this small source bundle is not a replacement for them.

The original files are preserved byte for byte; only this README, the
offline check and manifest are newly added. No additional public reuse
license is granted. Third-party software and data keep their own licenses.
