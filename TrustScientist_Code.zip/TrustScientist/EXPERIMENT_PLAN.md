# External framework integration experiment — EXT1

Protocol written before any formal cohort execution, 19 October 2026.

## Claims and prohibited interpretations
C1: The already-frozen recovery interface can be connected to a third-party
LangGraph workflow without editing its interface or existing engines, and can
restore registered reports, exports, queued jobs and downstream artifacts after
controlled evidence changes. C2: Resource ownership is reusable across recovery
backends; integration requirements and its containment boundary are measurable.
No exclusive replay algorithm, token advantage, scientific noninferiority,
developer productivity, natural omission probability or production/distributed
reliability is claimed. The actor and integrator are automated; human involvement
is not simulated. These are new-to-this-project tasks, not a community benchmark
or proof of absence from model pretraining.

## Freeze and task selection
INTERFACE_FREEZE.json binds verbatim workflow_interface.py, trust_engine.py and
generic_replay.py from the previous WF3 experiment. They must remain unchanged.
Framework glue and a native-checkpointer adapter are separate files. Infrastructure
and numerical test code are debugged only using a synthetic smoke task. Formal
task instructions, reference calculations, inputs, runtime, baseline and protocol
are hashed before the first formal model request. Any later correction creates a
separate revision, retaining original results and denominators; no task replacement.

Six public datasets distributed by statsmodels 0.15.0, absent from previous
project task registries: co2, sunspots, nile, grunfeld, copper, macrodata. Questions
are descriptive time-series or panel computations with explicit missing-data,
aggregation and regression rules. Initial input is the earliest 70 percent of
time points (all entities at those points); expanded input contains all time
points. The full histories are historical public data, not newly collected data.
Scientific suitability of these prescribed analyses is not established by replay.

Seeds: 20261031, 20261032, 20261033. Thus 18 histories, six independent dataset
families rather than 18 independent domains. New seeds do not increase domain
diversity. Dataset provenance and exact exported CSV hashes are saved.

## Third-party framework and arms
Use pinned LangGraph 1.2.16 and langgraph-checkpoint-sqlite 3.1.2. The graph must
actually execute preparation, model code generation, sandboxed tool execution,
conditional repair, model reporting, publication and a local SQLite worker.
Use the framework's SQLite checkpoints, state history and invoke(None, config)
to resume from the saved pre-analysis checkpoint; do not substitute a mock graph.
The generated code has at most three attempts based on real errors and public
input inspection. Verifier answers/host files are never mounted into the actor.
Numerical feedback identifies failed requirements without giving target values.

Six principal arms cross three backends with two interfaces:
1. Frozen TrustScientist Store;
2. Frozen independent GenericReplay;
3. Native LangGraph checkpoint-backed receipt and explicit resource recovery.
Each gets complete explicit path registration or the identical frozen managed
directory interface. The native baseline gets the same policies, information,
resource sets, restart point and continuation budget. A seventh checkpoint-only
arm is diagnostic: framework state replay alone, with no application resource
withdrawal. It is not characterized as a complete recovery baseline.

All arms use the same local Qwen3-8B checkpoint, prompts, seed, reference checks,
tool budget, and requested output products. Exact-request response caching pairs
model outputs across arms; graph nodes and analysis tools still execute per arm.
Report actual physical tokens once, plus complete logical tokens per arm, including
initialization, failed requests and retries. Rotate arm order by task/seed.
Do not interpret cached timing as equal-cache-warmth engine speed.

## Changes and denominators
Each history receives three consecutive controlled changes: expanded data,
one predefined additional metric, then a +0.25 defect added to a required estimate
in the generated code and actually executed. The code defect is a controlled
corruption, not a natural bug. Replaying may regenerate from the current task or
retrieve cached clean code; do not claim autonomous diagnosis of the injected bug.
18 initial histories per arm; 54 planned update slots per arm; 378 normal slots
across seven arms. Initial/recovery failure never disappears: later unexecuted
slots remain in planned denominators. No extra repair round after formal results.

## Metrics and independent checks
Primary: current numerical contract conformance AND withdrawal of stale reports,
exports, pending jobs and follow-up products, authentic LangGraph pre-analysis
checkpoint replay, final product/provenance consistency, and independent worker
arithmetic. Count old jobs actually consumed. Narrative validity is separate and
not scored as scientific truth. A separately written calculation reads public
inputs, never actor estimates, to calculate reference quantities. Retain code,
predictions if any, request/response bodies, per-node/checkpoint traces, outputs,
error logs, audit trails and planned/observed record counts.

## Omission probes
On each available initial state, clone and separately omit report, export, queue,
follow-up or data registration; sixth probe moves the pending queue outside the
owned output directory. Six probes x 18 histories x six principal arms = 648
planned observations. Managed per-output probes test containment, since there is
no corresponding individual registration statement to delete; they are not
equivalent source mutations or estimates of natural programmer errors. Test
withdrawal before letting the worker consume pending old jobs. Code outside the
ownership root requires explicit compensation and is an expected boundary.

## Integration and cost accounting
Save an unintegrated native LangGraph workflow and exact integration patch.
Measure added/removed nonblank non-comment source lines, modified files, API
touchpoints, explicit resource declarations, and wrapper/backend code separately.
Exclude task prompts, verifier code, instrumentation and fault injection from the
application integration count; report their sizes separately for transparency.
Automatic edit and execution timestamps are not human development time.
Record model input/output/total usage, cache hits, setup and formal usage,
wall/CPU/RSS, graph DB and materialized bytes, GPU-board energy in the measured
window, failures and missing usage. GPU startup, idle, review-assistant usage and
whole-host energy are not silently zero. No complete financial cost claimed.

## Execution order and limits
M0 isolated new framework environment; seeded GPU/CPU/native-checkpoint/sandbox
witness; fresh agent follows the documented invocation. M1 synthetic smoke and
protocol audit. M2 full frozen cohort, at most three concurrent task histories,
six new tasks x three seeds; local GPU only, no paid APIs. M3 omission probes,
deterministic verification and fresh integrity audit. M4 report actual results,
preserve all old manuscript figures/results, update Overleaf and attachment index.
Expected active inference is tens of minutes; actual duration is logged. A safety
ceiling of 1,000,000 actual model tokens stops further requests and marks remaining
slots unexecuted if reached. This is a resource limit, not an outcome-based stop.

## Human work (separate, not a dependency for automated execution)
Independent developers must measure onboarding time, integration mistakes,
debugging effort and maintenance under an unexpected added resource, using
counterbalanced interfaces and equivalent task packets. Prepare blank logs and
instructions; do not fill labels or pretend model agents are independent people.
Independent domain readers can assess report claims and recommended next actions.
No human evaluation is asserted until people actually complete it.

## Preformal corrections retained
Before any formal cohort requests, remove static row counts from schema (live profile supplies current count); require an exact estimate-key set so validation and downstream arithmetic agree; make response persistence atomic with a globally reserved 16,384-token context bound, preserving reservations for unknown usage; verify both original freezes and snapshot the cache at formal start. Summaries use the fixed ID matrix, expose missing/duplicate records and unknown usage/old-job counts. These changes affect every arm equally and were tested with synthetic witnesses, without changing the frozen interface or either existing backend.

