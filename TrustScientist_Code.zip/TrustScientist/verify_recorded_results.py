"""Offline checks of recorded EXT1 denominators; no model/API calls."""
from pathlib import Path
import json, collections, hashlib
R=Path(__file__).resolve().parent
def rows(n):return [json.loads(x) for x in (R/n).read_text().splitlines() if x.strip()]
initial=rows('runs_initial_records.jsonl');updates=rows('runs_records.jsonl');faults=rows('runs_fault_records.jsonl')
summary=json.loads((R/'SUMMARY.json').read_text())
for arm,expected in summary['arms'].items():
    a=[x for x in initial if x['arm']==arm];n=[x for x in updates if x['arm']==arm]
    assert len(a)==18 and sum(x['correct'] for x in a)==5
    assert len(n)==54 and sum(x['executed'] for x in n)==12
    assert len({(x['task'],x['seed'],x['event']) for x in n})==54
    assert sum(x['correct'] for x in n)==expected['normal_correct']
    assert sum(x['old_jobs_executed'] is None for x in n)==42
    assert sum(x['old_jobs_executed'] or 0 for x in n)==expected['old_jobs_executed']
    if arm!='checkpoint_only':
        f=[x for x in faults if x['arm']==arm]
        inside=[x for x in f if x['probe']!='external_queue'];outside=[x for x in f if x['probe']=='external_queue']
        assert len(inside)==90 and sum(x['executed'] for x in inside)==25
        assert sum(x['safe_withdrawal'] for x in inside)==(25 if arm.endswith('managed') else 0)
        assert len(outside)==18 and sum(x['executed'] for x in outside)==5
        assert sum(x['safe_withdrawal'] for x in outside)==0
    print(arm,':',sum(x['correct'] for x in n),'/54 planned;',sum(x['correct'] for x in n),'/12 attempted')
manifest=json.loads((R/'SOURCE_MANIFEST.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
print('PASS: recorded counts, missing outcomes, omissions and source hashes. Scientific validity and fresh inference are not tested.')
