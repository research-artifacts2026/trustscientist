"""Framework-specific glue; the frozen interface and old engines are unmodified.
Fault-injection code is kept in run_experiment.py, outside this measured module.
"""
from pathlib import Path
from frozen.workflow_interface import WorkflowInterface
from frozen.trust_engine import Store
from frozen.generic_replay import GenericReplay
from native_backend import NativeCheckpointRecovery
import runtime as rt

class RecoveryIntegration:
 def __init__(self,root,runner,backend,managed):
  self.root=Path(root);self.runner=runner
  factory={'trust':Store,'generic':GenericReplay,'native':NativeCheckpointRecovery}[backend]
  engine=factory(root,{'release':rt.gate},runner) if backend=='native' else factory(root,{'release':rt.gate})
  self.interface=WorkflowInterface(engine,managed)
 def register(self,bindings=None,outputs=None):
  if bindings is None:bindings=sorted(p.relative_to(self.root).as_posix() for p in (self.root/'evidence').iterdir() if p.is_file())
  if outputs is None:outputs=list(rt.EFFECTS)
  checkpoint=self.runner.pre_analysis_checkpoint()
  self.interface.register(self.root,'release',bindings,{},'proceed',outputs,checkpoint)
  return checkpoint
 def recover(self):
  result=self.interface.revalidate()
  if result.get('blocked'):return result,None
  checkpoint=rt.read(self.root/'checkpoint.json') if result.get('rollback_index') is not None else None
  return result,checkpoint
