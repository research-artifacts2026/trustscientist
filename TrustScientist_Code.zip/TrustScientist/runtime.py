from pathlib import Path
import json,hashlib,os,re,time,sqlite3,shutil,subprocess,resource,signal,urllib.request,fcntl,uuid
import pandas as pd
from numeric_reference import check
R=Path(__file__).resolve().parent
WORKER='/disk2/fangxinyue/TrustScientist/.venv/bin/python'
VENV=str(Path(WORKER).parent.parent);UV='/home/fangxinyue/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu';UV_REAL=str(Path(WORKER).resolve().parent.parent)
PUBLIC=['data.csv','task.json','schema.json','requirements.json']
EFFECTS=['products/report','products/export','products/queue','products/followup']
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False));os.replace(tmp,p)
def read(p):return json.loads(Path(p).read_text())
def valid_usage(u):return isinstance(u,dict) and all(type(u.get(k)) is int and u[k]>=0 for k in ['prompt_tokens','completion_tokens','total_tokens']) and u['total_tokens']==u['prompt_tokens']+u['completion_tokens'] and u['total_tokens']<=16384
def log(w,kind,**x):
 with (Path(w)/'cost.jsonl').open('a') as f:f.write(canonical({'time':time.time(),'kind':kind,**x})+'\n')
def inputs(w):return {n:sha(Path(w)/'evidence'/n) for n in PUBLIC}
def llm(w,messages,seed,kind,max_tokens=4500):
 cache=R/'api_cache';cache.mkdir(exist_ok=True)
 payload={'model':'trust-pilot-qwen3-8b','messages':messages,'seed':seed,'temperature':.2 if kind=='code' else 0.,'top_p':1,'max_tokens':max_tokens,'chat_template_kwargs':{'enable_thinking':False}}
 key=hashlib.sha256(canonical(payload).encode()).hexdigest();dest=cache/(key+'.response.json');start=time.monotonic()
 with (cache/(key+'.lock')).open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  hit=dest.exists()
  if hit:ans=read(dest)
  else:
   # Global reservation uses the server's full context cap as a conservative
   # upper bound, including unknown-usage failures. Different requests may run
   # concurrently; files become visible only after atomic replacement.
   reservation=cache/(key+'.reservation.json')
   if reservation.exists():raise RuntimeError('Earlier identical request has unknown usage; reservation retained, no automatic retry')
   with (cache/'budget.lock').open('a') as budget:
    fcntl.flock(budget,fcntl.LOCK_EX)
    total=sum(u['total_tokens'] for p in cache.glob('*.response.json') if valid_usage(u:=read(p).get('usage')))
    reserved=sum(read(p)['reserved_tokens'] for p in cache.glob('*.reservation.json'))
    if total+reserved+16384>1000000:raise RuntimeError('Prespecified resource token ceiling reached')
    put(reservation,{'reserved_tokens':16384,'time':time.time(),'key':key})
   put(cache/(key+'.request.json'),payload)
   req=urllib.request.Request('http://127.0.0.1:18346/v1/chat/completions',data=canonical(payload).encode(),headers={'Content-Type':'application/json'})
   try:
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=240) as f:ans=json.load(f)
   except Exception as exc:log(w,'api_error',key=key,request_kind=kind,seconds=time.monotonic()-start,error=repr(exc),usage='unknown');raise
   with (cache/'budget.lock').open('a') as budget:
    fcntl.flock(budget,fcntl.LOCK_EX);put(dest,ans)
    if valid_usage(ans.get('usage')):reservation.unlink()
 log(w,'api',key=key,request_kind=kind,cache_hit=hit,usage=ans.get('usage'),usage_valid=valid_usage(ans.get('usage')),seconds=time.monotonic()-start)
 return ans['choices'][0]['message']['content']

def setup(w,task):
 w=Path(w);w.mkdir(parents=True,exist_ok=False);shutil.copytree(R/'tasks'/task/'initial',w/'evidence')

def inspect_public(w):
 start=time.monotonic();e=Path(w)/'evidence';d=pd.read_csv(e/'data.csv')
 profile={'rows':len(d),'columns':list(d.columns),'missing':{k:int(v) for k,v in d.isna().sum().items() if v},'preview':json.loads(d.head(3).to_json(orient='records'))}
 put(e/'public_profile.json',profile);log(w,'public_inspection',seconds=time.monotonic()-start);return profile

def code_messages(w):
 e=Path(w)/'evidence';task=read(e/'task.json');req=read(e/'requirements.json');profile=inspect_public(w)
 prompt=('Write a complete executable Python script, code only, no markdown. Use real CSV data in /inputs/data.csv. No network. Available numpy, pandas, scipy, sklearn; statsmodels is NOT available in the code execution sandbox. Use numpy.linalg.lstsq for OLS. Write /work/analysis.json as an object with estimates (numeric dictionary), method (string), limitations (list). Never invent numbers. '
 +task['question']+'\nMandatory estimate keys: '+canonical(task['estimate_keys'])+'\nAdditional mandatory metrics: '+canonical(req['additional_metrics'])+'\nData schema: '+canonical(read(e/'schema.json'))+'\nObserved public data profile: '+canonical(profile)
 +'\nThe estimates dictionary must contain EXACTLY the mandatory and additional mandatory metric keys above, with no extra keys. Follow exact missing-data and denominator rules. Convert numpy scalars to float/int before JSON. You have access only to the four public input files; no reference answers. Read data to calculate estimates. No confidence intervals or hypothesis tests are requested. /no_think')
 return [{'role':'system','content':'You are a research coding agent. Execute the prescribed descriptive analysis with actual data; do not fabricate outputs.'},{'role':'user','content':prompt}]

def generate(w,messages,seed):
 raw=llm(w,messages,seed,'code');code=re.sub(r'^```(?:python)?\s*','',raw.strip());code=re.sub(r'\s*```$','',code);(Path(w)/'evidence/code.py').write_text(code);return code

def execute(w):
 w=Path(w);e=w/'evidence';out=w/'attempts'/f'{len(list((w/"attempts").glob("*"))):03d}';out.mkdir(parents=True)
 shutil.copy2(e/'code.py',out/'code.py');actor=w/'actor_inputs'/out.name;actor.mkdir(parents=True)
 for n in PUBLIC:shutil.copy2(e/n,actor/n)
 put(out/'actor_input_manifest.json',{p.name:sha(p) for p in actor.iterdir()})
 cmd=['bwrap','--ro-bind','/usr','/usr','--ro-bind','/lib','/lib','--ro-bind','/lib64','/lib64','--ro-bind',UV_REAL,UV,'--ro-bind',VENV,VENV,'--unshare-all','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind',str(actor.resolve()),'/inputs','--bind',str(out.resolve()),'/work','--chdir','/work','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','OMP_NUM_THREADS','2','--setenv','OPENBLAS_NUM_THREADS','2','--setenv','MKL_NUM_THREADS','2','/usr/bin/time','-f','%U %S %M %e %x','-o','/work/resources.txt',WORKER,'-I','/work/code.py']
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(100*1024*1024,100*1024*1024))
 start=time.monotonic()
 with (out/'stdout.txt').open('w') as so,(out/'stderr.txt').open('w') as se:
  proc=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True,preexec_fn=limits)
  try:exit_code=proc.wait(timeout=150)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait();exit_code=-124
 usage={'seconds':time.monotonic()-start,'exit_code':exit_code,'output':str(out.relative_to(w))}
 try:
  fields=(out/'resources.txt').read_text().splitlines()[-1].split();usage.update(cpu_user_s=float(fields[0]),cpu_sys_s=float(fields[1]),max_rss_kib=int(fields[2]))
 except Exception:usage['resource_measurement_missing']=True
 log(w,'tool',**usage);put(out/'execution_cost.json',usage)
 try:
  if exit_code!=0:raise RuntimeError('sandbox execution failed')
  analysis=read(out/'analysis.json');canonical(analysis);shutil.copy2(out/'analysis.json',e/'analysis.json')
  start=time.monotonic();verdict=check(read(e/'task.json')['id'],e,analysis);log(w,'reference',seconds=time.monotonic()-start,passed=verdict['pass'])
 except Exception as exc:verdict={'pass':False,'errors':[type(exc).__name__+': '+str(exc)]}
 put(e/'verification.json',verdict);put(out/'verification.json',verdict)
 put(e/'provenance.json',{'inputs':inputs(w),'code':sha(e/'code.py'),'analysis':sha(e/'analysis.json') if (e/'analysis.json').exists() else None,'verification':sha(e/'verification.json'),'execution_ok':exit_code==0})
 feedback=(out/'stderr.txt').read_text()[-2500:]+'\nActual stdout: '+(out/'stdout.txt').read_text()[-1500:]
 feedback+='\nContract check errors (no target values): '+canonical(verdict['errors'])
 return verdict['pass'],feedback

def gate(root,bindings,context):
 e=Path(root)/'evidence'
 try:
  p=read(e/'provenance.json');v=read(e/'verification.json')
  fresh=p['inputs']==inputs(root) and p['code']==sha(e/'code.py') and p['analysis']==sha(e/'analysis.json') and p['verification']==sha(e/'verification.json')
  return 'proceed' if fresh and p['execution_ok'] and v['pass'] else 'refine'
 except Exception:return 'refine'

def binding(w):
 e=Path(w)/'evidence';return {'inputs':inputs(w),'code':sha(e/'code.py'),'analysis':sha(e/'analysis.json')}

def report(w,seed):
 e=Path(w)/'evidence';prompt='Write a short descriptive research report and justified next analysis using only these executed results. No invented p-values, significance, confidence intervals, forecasts or causal conclusions. Explicitly state only listed numerical contracts were checked. Task: '+read(e/'task.json')['question']+'\nResults: '+canonical(read(e/'analysis.json'))+'\nRequirements: '+canonical(read(e/'requirements.json'))+' /no_think'
 return llm(w,[{'role':'system','content':'Write a cautious research report. Numerical conformance does not establish scientific validity.'},{'role':'user','content':prompt}],seed,'report',800)

def publish(w,narrative):
 w=Path(w);x=read(w/'evidence/analysis.json');b=binding(w)
 put(w/'products/report/report.json',{'binding':b,'estimates':x['estimates'],'narrative':narrative})
 (w/'products/report/report.md').write_text(narrative+'\n\nExecuted estimates:\n'+json.dumps(x['estimates'],indent=2))
 put(w/'products/export/results.json',{'binding':b,'values':x['estimates']});enqueue(w)

def enqueue(w):
 w=Path(w);report=read(w/'products/report/report.json');q=w/'products/queue/jobs.sqlite';q.parent.mkdir(parents=True,exist_ok=True)
 con=sqlite3.connect(q);con.execute('CREATE TABLE IF NOT EXISTS jobs (id INTEGER PRIMARY KEY, report_sha TEXT, payload TEXT, status TEXT)')
 con.execute('INSERT INTO jobs(report_sha,payload,status) VALUES (?,?,?)',(sha(w/'products/report/report.json'),canonical(report),'pending'));con.commit();con.close()

def consume(w,queue=None):
 w=Path(w);q=Path(queue) if queue else w/'products/queue/jobs.sqlite'
 if not q.exists():return []
 con=sqlite3.connect(q);jobs=con.execute("SELECT id,report_sha,payload FROM jobs WHERE status='pending'").fetchall();done=[]
 for rid,rsha,payload in jobs:
  x=json.loads(payload);est=x['estimates'];obj={'binding':x['binding'],'source_report_sha':rsha,'derived':{'metric_count':len(est),'sum_of_estimates':sum(est.values())},'scope':'Local reversible diagnostic downstream operation; no external scientific action'}
  put(w/'products/followup/result.json',obj);con.execute('UPDATE jobs SET status=? WHERE id=?',('done',rid));done.append(obj)
 con.commit();con.close();return done

def inspect_outputs(w):
 w=Path(w);e=w/'evidence';checks={}
 try:
  b=binding(w);a=read(e/'analysis.json')['estimates'];v=read(e/'verification.json');target=v['expected']
  for kind,path,key in [('report','products/report/report.json','estimates'),('export','products/export/results.json','values')]:
   obj=read(w/path);checks[kind]=obj['binding']==b and obj[key]==a
  follow=read(w/'products/followup/result.json');checks['followup']=follow['binding']==b and follow['source_report_sha']==sha(w/'products/report/report.json')
  checks['downstream_arithmetic']=abs(follow['derived']['sum_of_estimates']-sum(target.values()))<=1e-5*max(1,abs(sum(target.values()))) and follow['derived']['metric_count']==len(target)
  con=sqlite3.connect(w/'products/queue/jobs.sqlite');jobs=con.execute('SELECT report_sha,payload,status FROM jobs').fetchall();con.close();checks['queue']=bool(jobs) and all(json.loads(payload)['binding']==b and status=='done' and rsha==sha(w/'products/report/report.json') for rsha,payload,status in jobs)
  checks['numeric_contract']=gate(w,[],{})=='proceed'
 except Exception as exc:checks['error']=repr(exc);checks['all']=False;return checks
 checks['all']=all(checks.values());return checks
