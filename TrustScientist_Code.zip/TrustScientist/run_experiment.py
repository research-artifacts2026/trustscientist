from pathlib import Path
import json,time,shutil,concurrent.futures,threading,traceback,os
import runtime as rt
from framework_workflow import GraphRunner
from integration import RecoveryIntegration

R=Path(__file__).resolve().parent
TASKS=['co2','sunspots','nile','grunfeld','copper','macrodata'];SEEDS=[20261031,20261032,20261033]
ARMS=['trust_managed','generic_managed','native_managed','trust_manual','generic_manual','native_manual','checkpoint_only']
PROBES=['omit_report','omit_export','omit_queue','omit_followup','omit_data','external_queue']
LOCK=threading.Lock()
def append(path,obj):
 with LOCK:
  with Path(path).open('a') as f:f.write(rt.canonical(obj)+'\n')
def policy_integration(w,g,arm):
 if arm=='checkpoint_only':return None
 backend,interface=arm.split('_');return RecoveryIntegration(w,g,backend,interface=='managed')
def expanded(w,task):shutil.copy2(R/'tasks'/task/'expanded/data.csv',Path(w)/'evidence/data.csv')
def mutate(w,task,event):
 w=Path(w);e=w/'evidence'
 if event=='data':expanded(w,task)
 elif event=='metric':
  extra={'median':'Median of x'} if task=='smoke' else next(r['extra'] for r in rt.read(R/'TASK_REGISTRY.json') if r['dataset']==task)
  rt.put(e/'requirements.json',{'version':2,'additional_metrics':extra})
 else:
  key=rt.read(e/'task.json')['estimate_keys'][0]
  code=(e/'code.py').read_text()+"\n# Controlled executed numeric defect\nimport json\np='/work/analysis.json'\na=json.load(open(p))\na['estimates']["+repr(key)+"] += 0.25\njson.dump(a,open(p,'w'))\n"
  (e/'code.py').write_text(code);ok,_=rt.execute(w)
  if ok:raise RuntimeError('injected numeric defect passed; protocol violation')

def remove_new_clone_state(p,root):
 p=Path(p).resolve();root=Path(root).resolve()
 assert p.is_relative_to(root) and p!=root
 if p.exists():shutil.rmtree(p)

def fault_probes(snapshot,task,seed,arm,group):
 if arm=='checkpoint_only':return
 for probe in PROBES:
  w=R/(group+'_faults')/task/str(seed)/arm/probe
  record={'task':task,'seed':seed,'arm':arm,'probe':probe,'planned':True,'executed':False,'safe_withdrawal':False,'old_jobs_executed':None}
  g=None
  try:
   shutil.copytree(snapshot,w)
   for name in ['.cbr','.generic']:remove_new_clone_state(w/name,w)
   g=GraphRunner(w);adapter=policy_integration(w,g,arm)
   bindings=sorted(p.relative_to(w).as_posix() for p in (w/'evidence').iterdir() if p.is_file());outputs=list(rt.EFFECTS)
   if probe=='omit_data':bindings.remove('evidence/data.csv')
   if probe.startswith('omit_') and probe!='omit_data':outputs.remove('products/'+probe[5:])
   adapter.register(bindings=bindings,outputs=outputs);rt.enqueue(w)
   queue=w/'products/queue/jobs.sqlite'
   if probe=='external_queue':
    external=w/'outside_owned_root/jobs.sqlite';external.parent.mkdir();shutil.move(queue,external);queue=external
   expanded(w,task);start=time.monotonic();decision,checkpoint=adapter.recover()
   safe=all(not (w/p).exists() for p in rt.EFFECTS) and not queue.exists()
   old=rt.consume(w,queue);record.update(executed=True,safe_withdrawal=safe,old_jobs_executed=len(old),rollback=checkpoint is not None,decision=decision,seconds=time.monotonic()-start)
   rt.put(w/'FAULT_RECORD.json',record)
  except Exception as exc:record['error']=repr(exc);record['traceback']=traceback.format_exc()
  finally:
   if g:
    try:g.close()
    except Exception as exc:record['close_error']=repr(exc)
  append(R/(group+'_fault_records.jsonl'),record)

def history(task,seed,group='runs',with_faults=True):
 rotation=(seed+TASKS.index(task) if task in TASKS else seed)%len(ARMS);arms=ARMS[rotation:]+ARMS[:rotation]
 for arm in arms:
  w=R/group/task/str(seed)/arm;g=None;alive=False
  initial={'task':task,'seed':seed,'arm':arm,'phase':'initial','planned':True,'executed':False,'correct':False}
  try:
   rt.setup(w,task);g=GraphRunner(w);state=g.start(seed);initial['executed']=True
   alive=bool(state.get('ok')) and rt.gate(w,[],{})=='proceed'
   if alive:
    cp=g.pre_analysis_checkpoint();adapter=policy_integration(w,g,arm)
    if adapter:adapter.register()
    rt.put(w/'initial_checkpoint.json',cp);g.dispatch();initial['checks']=rt.inspect_outputs(w);alive=initial['checks']['all'];initial['correct']=alive
   g.close();g=None
   if alive:
    snapshot=R/(group+'_initial_snapshots')/task/str(seed)/arm;shutil.copytree(w,snapshot)
    if with_faults:fault_probes(snapshot,task,seed,arm,group)
  except Exception as exc:initial['error']=repr(exc);initial['traceback']=traceback.format_exc();alive=False
  finally:
   if g:
    try:g.close()
    except Exception:pass
   g=None
  append(R/(group+'_initial_records.jsonl'),initial)
  if not alive and with_faults and arm!='checkpoint_only':
   for probe in PROBES:append(R/(group+'_fault_records.jsonl'),{'task':task,'seed':seed,'arm':arm,'probe':probe,'planned':True,'executed':False,'safe_withdrawal':False,'old_jobs_executed':None,'reason':'initial analysis failed'})
  for event in ['data','metric','code_defect']:
   rec={'task':task,'seed':seed,'arm':arm,'event':event,'planned':True,'executed':False,'safe_withdrawal':False,'correct':False,'old_jobs_executed':None};start=time.monotonic()
   if not alive:
    rec['reason']='previous stage failed';append(R/(group+'_records.jsonl'),rec);continue
   try:
    rt.enqueue(w);mutate(w,task,event);g=GraphRunner(w);adapter=policy_integration(w,g,arm)
    if adapter:decision,cp=adapter.recover()
    else:decision={'diagnostic':'framework state replay without application cleanup'};cp=rt.read(w/'initial_checkpoint.json')
    rec['decision']=decision;rec['executed']=True
    rec['safe_withdrawal']=all(not (w/p).exists() for p in rt.EFFECTS)
    old=rt.consume(w);rec['old_jobs_executed']=len(old)
    if cp is None or decision.get('blocked'):
     rec['reason']='no completed recovery checkpoint';alive=False
    else:
     state=g.resume(cp);rec['native_checkpoint']=cp
     alive=bool(state.get('ok')) and rt.gate(w,[],{})=='proceed'
     if alive:
      if adapter:adapter.register()
      g.dispatch();rec['checks']=rt.inspect_outputs(w)
      rec['correct']=rec['safe_withdrawal'] and not old and rec['checks']['all']
      # Checkpoint-only diagnostics continue despite stale external effects.
      alive=bool(state.get('ok')) if arm=='checkpoint_only' else rec['correct']
     else:rec['reason']='regenerated analysis failed'
    rec['seconds']=time.monotonic()-start
    out=w/'event_snapshots'/event;out.mkdir(parents=True)
    for name in ['evidence','products']:
     if (w/name).exists():shutil.copytree(w/name,out/name)
    rt.put(out/'RECORD.json',rec)
   except Exception as exc:rec['error']=repr(exc);rec['traceback']=traceback.format_exc();alive=False
   finally:
    if g:
     try:g.close()
     except Exception as exc:rec['close_error']=repr(exc)
    g=None
   append(R/(group+'_records.jsonl'),rec)
  print(rt.canonical({'finished':task,'seed':seed,'arm':arm,'initial_correct':initial['correct']}),flush=True)

def main():
 assert (R/'FORMAL_FREEZE.json').exists(),'Formal freeze required'
 assert not (R/'runs_records.jsonl').exists(),'Never overwrite a formal run'
 freeze=rt.read(R/'FORMAL_FREEZE.json')
 assert all(rt.sha(R/p)==h for p,h in freeze['files'].items()),'Source or data changed after freeze'
 rt.put(R/'formal_start.json',{'time':time.time(),'planned_initial':126,'planned_normal':378,'planned_faults':648})
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(history,t,s) for t in TASKS for s in SEEDS]
  for f in concurrent.futures.as_completed(futures):f.result()
 rt.put(R/'formal_end.json',{'time':time.time(),'completed':True})
if __name__=='__main__':main()
