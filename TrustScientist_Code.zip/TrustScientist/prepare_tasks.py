from pathlib import Path
import json,hashlib,math,shutil,datetime
import numpy as np
import statsmodels,statsmodels.api as sm
R=Path(__file__).resolve().parent
SPECS={
 'co2':('Describe observed Mauna Loa atmospheric CO2. Drop rows missing co2. Report mean_co2 and slope_per_year from OLS co2 on an intercept and supplied decimal_year. Use all available finite observations; do not impute. These are descriptive, not causal or forecast estimates.', ['mean_co2','slope_per_year'], {'seasonal_range':'Group nonmissing co2 by supplied month (1..12), average each month over all observed years, then max minus min of those 12 monthly means.'}),
 'sunspots':('Describe annual solar activity. Sort YEAR ascending; report mean_activity and slope_per_year from OLS SUNACTIVITY on intercept and YEAR. No cycle or causal inference.', ['mean_activity','slope_per_year'], {'lag1_correlation':'Pearson correlation of adjacent SUNACTIVITY observations after sorting YEAR ascending; pair x[:-1] with x[1:].'}),
 'nile':('Describe Nile discharge at Aswan in the supplied volume units. Report mean_volume and median_volume over nonmissing volume. Do not infer a cause for changes.', ['mean_volume','median_volume'], {'post1900_minus_pre1900':'Mean volume for year >=1900 minus mean volume for year <1900; omit missing volume within each group.'}),
 'grunfeld':('Fit the explicitly specified descriptive pooled OLS: invest = intercept + value_coef * value + capital_coef * capital. Include all firms and complete rows, no firm dummies. Report intercept, value_coef, capital_coef. Coefficients are associations, not causal effects.', ['intercept','value_coef','capital_coef'], {'within_value_coef':'Demean invest, value and capital within each firm over complete rows. Regress demeaned invest jointly on demeaned value and capital WITHOUT intercept; report coefficient on demeaned value.'}),
 'copper':('Fit descriptive log-log OLS: log(WORLDCONSUMPTION) = intercept + price_coef * log(COPPERPRICE) + income_coef * log(INCOMEINDEX). Use complete strictly positive rows. Do not include other columns or TIME as predictors. Report intercept, price_coef, income_coef. No causal elasticity interpretation.', ['intercept','price_coef','income_coef'], {'r_squared':'1 minus residual sum of squares divided by centered total sum of squares, on log WORLDCONSUMPTION in the same fit.'}),
 'macrodata':('Sort rows by year and quarter. Compute quarterly real GDP growth = 100 * (log(realgdp_t)-log(realgdp_previous)); omit the first undefined growth. Report mean_growth over these growth rows and mean_inflation over all nonmissing infl rows (including the first row). Do not multiply growth by 4. No causal inference.', ['mean_growth','mean_inflation'], {'growth_unemployment_correlation':'Pearson correlation between quarterly GDP growth and same-quarter unemp, on complete pairs; omit first undefined growth.'}),
}
def save(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,allow_nan=False))
def main():
 assert not (R/'TASK_FREEZE.json').exists(),'Task freeze already exists'
 rows=[]
 for name,(question,keys,extra) in SPECS.items():
  module=getattr(sm.datasets,name);d=module.load_pandas().data.copy()
  if name=='co2':
   dates=d.index;d.insert(0,'date',dates.strftime('%Y-%m-%d'));d['decimal_year']=dates.year+(dates.dayofyear-1)/365.25;d['month']=dates.month;order=np.arange(len(d));time=d['date']
  elif name=='macrodata':d=d.sort_values(['year','quarter']);time=d['year']*4+d['quarter']
  elif name=='grunfeld':d=d.sort_values(['year','firm']);time=d['year']
  elif name=='copper':d=d.sort_values('TIME');time=d['TIME']
  elif name=='nile':d=d.sort_values('year');time=d['year']
  else:d=d.sort_values('YEAR');time=d['YEAR']
  points=sorted(time.unique());cut=points[max(1,math.floor(len(points)*.7))-1]
  initial=d.loc[time<=cut].copy();d=d.reset_index(drop=True);initial=initial.reset_index(drop=True)
  for phase,frame in [('initial',initial),('expanded',d)]:
   dest=R/'tasks'/name/phase;dest.mkdir(parents=True,exist_ok=True);frame.to_csv(dest/'data.csv',index=False)
   save(dest/'task.json',{'id':name,'question':question,'estimate_keys':keys})
   save(dest/'schema.json',{'columns':list(frame.columns),'rows':len(frame),'source_note':getattr(module,'NOTE',''),'analysis_scope':'Descriptive registered computation; no scientific validity guarantee.'})
   save(dest/'requirements.json',{'version':1,'additional_metrics':{}})
  provenance={'dataset':name,'distribution':'statsmodels '+statsmodels.__version__,'source':getattr(module,'SOURCE',''),'copyright':getattr(module,'COPYRIGHT',''),'module_file':str(Path(module.__file__).name),'initial_rows':len(initial),'expanded_rows':len(d),'split':'earliest floor(70% of unique time points), all entities at those times','extra':extra,'new_to_project_task_registry':True}
  save(R/'tasks'/name/'PROVENANCE.json',provenance);rows.append(provenance)
 save(R/'TASK_REGISTRY.json',rows)
 hashes={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((R/'tasks').rglob('*')) if p.is_file()}
 save(R/'TASK_FREEZE.json',{'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':hashes,'task_ids':list(SPECS),'selection_before_formal_model_requests':True})
 print(json.dumps([{k:x[k] for k in ['dataset','initial_rows','expanded_rows']} for x in rows],indent=2))
if __name__=='__main__':main()
